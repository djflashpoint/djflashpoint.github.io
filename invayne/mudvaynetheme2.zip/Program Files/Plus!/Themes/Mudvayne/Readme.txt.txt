********************************
*Mudvayne Desktop Theme Ver 1.0*
********************************


Hey how's it going...

This theme was created because well... because I wanted a Mudvayne theme and I didn't think that one would be popping up any time soon since L.D. 50 came out in August... I think.  Anyway all of the pictures used to make the wallpapers, icons, web views and the screen saver are off of the official Mudvayne website, which would be "www.mudvayne.com" <-- so go there! The shutdown logos were scanned from the picture on the back of the CD, with a little tweaking, and the startup logo was scanned from the reverse side of the same paper... check it out if you didn't buy a version with a completely clear case.  The cursors were ripped from a combination of another theme by John the Tykne "http://www.thefragile.com/echoingthesound" guy he is a theme gOD (no disrespect to John by referring him to gOD in any way) and the "Dig" video... ummm... that's about it...it probably not but...I'm really tired of typing "..."

If you have any questions or comments (not about my punctuation spelling or typos on this "readme" file...) you can e-mail me at plague.killer@sympatico.ca

All the audio files are compressed using the windows sound recorder with the Mpeg Layer-3 56k bit/s 22,050Hz Stereo blah blah blah.
