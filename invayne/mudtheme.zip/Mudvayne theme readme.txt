::Mudvayne.net Mudvayne Theme::

Thanks for visiting Mudvayne.net and downloading our theme!

This theme must be installed to your C:\Program Files\Plus!\Themes directory for it to work. Copy all the files in the folder to that directory. Then install the font (Ebola) in C:\Windows\Fonts. Then go into your themes program (it's in the Control Panel) and set Mudvayne.net as your theme! Its that easy! If you have any questions or comments please send them to: pete@mudvayne.net or adam@mudvayne.net. Thanks!

http://www.mudvayne.net (c)2000-Present